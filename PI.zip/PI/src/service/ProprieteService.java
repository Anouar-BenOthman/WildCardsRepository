/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import entity.Categorie;
import entity.Equipement;
import entity.Horaire;
import entity.Propriete;
import entity.ReseauSocial;
import entity.Tag;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import utils.DBConnection;

/**
 *
 * @author Nidhal
 */
public class ProprieteService implements IProprieteService{
    
    
    Statement ste;
    PreparedStatement pste;
    ResultSet rs;
    Connection cnx;
    
    
        EquipementService es = new EquipementService();
        HoraireService hs= new HoraireService();
        ReseauSocialService r= new ReseauSocialService();
        TagService ts =new TagService();
        ImgService is= new ImgService();
        CategorieService cs = new CategorieService();

    public ProprieteService() {
        this.cnx=(DBConnection.getInstanceBD()).getConnection();
    }

    @Override
    public boolean ajouterPropriete(Propriete p) throws SQLException {
        Connection cnx= DBConnection.cnx;
        String req="INSERT INTO `propriete`(`email`, `titre`, "
                + "`slogan`, `description`, `logo`, `cover`, `emailowner`, "
                + "`numtel`, `siteweb`, `adresse`, `latitude`, `longitude`,"
                + " `id_user`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?) ";
        pste=cnx.prepareStatement(req);
        pste.setString(1,p.getEmail());
        pste.setString(2,p.getTirte());
        pste.setString(3,p.getSlogan());
        pste.setString(4,p.getDescription());
        pste.setString(5,p.getLogo());
        pste.setString(6,p.getCover());
        pste.setString(7,p.getEmailOwner());
        pste.setString(8,p.getNumTel());
        pste.setString(9,p.getSiteWeb());
        pste.setString(10,p.getAdresse());
        pste.setFloat(11,p.getLatitude());
        pste.setFloat(12,p.getLongitude());
        pste.setInt(13,11);
        pste.executeUpdate();
        
        /*
        
        for(Categorie c :p.getCategorie()){
        cs.ajouterCategorie(c,p.getId());
        }
        
        for(Horaire h :p.getLshr()){
        hs.ajouterHoraire(h,p.getId());
        }

        for(Equipement e :p.getLsequi()){
        es.ajouterEquipement(e,p.getId());
        }

        for(Tag t :p.getLstag()){
        ts.ajouterTag(t,p.getId());
        }

        for(ReseauSocial re :p.getRs()){
        r.ajouterReseau(re,p.getId());
        }
        
        for(String s :p.getGallerie()){
        is.ajouterImg(s, 1);
        }*/
        
        return true;
    }

    @Override
    public ResultSet afficherPropriete() throws SQLException {
        Connection cnx= DBConnection.cnx;
        String req="SELECT * FROM propriete WHERE 1";
        ste=cnx.createStatement();
        rs=ste.executeQuery(req);
        
        return rs;
    }


    @Override
    public ResultSet chercherPropriete(int idPropriete) throws SQLException {
        Connection cnx= DBConnection.cnx;
        String req="SELECT * FROM propriete WHERE `id` ="+idPropriete;
        ste=cnx.createStatement();
        rs=ste.executeQuery(req);
        /*while(rs.next()){
            System.out.println(rs.getInt("id")+" ; "+rs.getString("email")+" ; "+rs.getString("titre"));
        }*/
        return rs;
    }
    


    @Override
    public ResultSet chercherPropriete(String s) throws SQLException {

        Connection cnx= DBConnection.cnx;
        String req="SELECT * FROM propriete WHERE `titre` like '"+s+"'";
        ste=cnx.createStatement();
        rs=ste.executeQuery(req);
        /*while(rs.next()){
            System.out.println(rs.getInt("id")+" ; "+rs.getString("email")+" ; "+rs.getString("titre"));
        }*/
        return rs;
    }

    @Override
    public boolean modifierPropriete(Propriete p) throws SQLException {
        Connection cnx= DBConnection.cnx;
         cs.supprimerCategorie(p.getId());
       
        hs.supprimerHoraire(p.getId());

        es.supprimerequipement(p.getId());

        ts.supprimerTag(p.getId());

        r.supprimerPropriete(p.getId());

        is.supprimerImg(p.getId());
        
       String req=" UPDATE `propriete` SET `id`="+p.getId()+",`email`=\""+
               p.getEmail()+"\",`titre`=\""+p.getTirte()+"\",`slogan`=\""+p.getSlogan()+
               "\",`description`=\""+p.getDescription()+"\",`logo`=\""+p.getLogo()+
               "\",`cover`=\""+p.getCover()+"\",`emailowner`=\""+p.getEmailOwner()+
               "\",`numtel`=\""+p.getNumTel()+"\",`siteweb`=\""+p.getSiteWeb()+
               "\",`adresse`=\""+p.getAdresse()+"\",`latitude`=\""+p.getLatitude()+
               "\",`longitude`=\""+p.getLongitude()+"\",`id_user`="+12+
               " WHERE `id`="+p.getId();
       ste=cnx.createStatement();
        ste.executeUpdate(req);
        
        for(Categorie c :p.getCategorie()){
        cs.ajouterCategorie(c,p.getId());
        }
        
        for(Horaire h :p.getLshr()){
        hs.ajouterHoraire(h,p.getId());
        }

        for(Equipement e :p.getLsequi()){
        es.ajouterEquipement(e,p.getId());
        }

        for(Tag t :p.getLstag()){
        ts.ajouterTag(t,p.getId());
        }

        for(ReseauSocial re :p.getRs()){
        r.ajouterReseau(re,p.getId());
        }
        
        for(String s :p.getGallerie()){
        is.ajouterImg(s, 1);
        }
        
       return true;
    }

    @Override
    public boolean supprimerPropriete(int idPropriete) throws SQLException {
        Connection cnx= DBConnection.cnx;
        cs.supprimerCategorie(idPropriete);
       
        hs.supprimerHoraire(idPropriete);
        

        
        es.supprimerequipement(idPropriete);
        

    
        ts.supprimerTag(idPropriete);
        

        
        r.supprimerPropriete(idPropriete);
        
        
        
        is.supprimerImg(idPropriete);
        
        String req="DELETE FROM `propriete` WHERE `id` ="+idPropriete;
        ste=cnx.createStatement();
        ste.executeUpdate(req);
        
        
        
        
        
        return true;
    }

    @Override
    public ResultSet indice() throws SQLException {
        Connection cnx= DBConnection.cnx;
        String req="SELECT `id` FROM propriete ORDER BY `id` DESC LIMIT 1";
        ste=cnx.createStatement();
        rs=ste.executeQuery(req);
        return rs;
    }
    
}
