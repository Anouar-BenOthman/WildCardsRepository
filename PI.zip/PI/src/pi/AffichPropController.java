/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pi;

import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXToggleButton;
import entity.Equipement;
import entity.Horaire;
import entity.Propriete;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.stage.Screen;
import javafx.stage.Stage;
import org.controlsfx.control.Rating;
import org.controlsfx.glyphfont.FontAwesome;
import org.controlsfx.glyphfont.Glyph;
import org.controlsfx.glyphfont.GlyphFont;
import org.controlsfx.glyphfont.GlyphFontRegistry;
import org.jpedal.PdfDecoderFX;
import org.jpedal.examples.viewer.Viewer;
import org.jpedal.exception.PdfException;
import service.EquipementService;
import service.HoraireService;
import service.ImgService;
import service.ProprieteService;

/**
 * FXML Controller class
 *
 * @author Nidhal
 */
public class AffichPropController implements Initializable {

    @FXML
    private Button ajoutprp;
    @FXML
    private Button inscBTN;
    @FXML
    private Button connecBTN;
    private Glyph cfx;
    GlyphFont fontAwesome = GlyphFontRegistry.font("FontAwesome");
    @FXML
    private Label titre;
    @FXML
    private Label slogan;
    @FXML
    private JFXCheckBox parking;
    @FXML
    private JFXCheckBox fumeur;
    @FXML
    private JFXCheckBox wifi;
    @FXML
    private JFXCheckBox ascenseur;
    @FXML
    private JFXCheckBox carte;
    @FXML
    private JFXCheckBox event;
    @FXML
    private JFXCheckBox espaceTravail;
    @FXML
    private JFXCheckBox parkingRue;
    @FXML
    private JFXCheckBox fauteuilRoulant;
    @FXML
    private JFXCheckBox enfant;
    @FXML
    private JFXCheckBox exterieur;
    @FXML
    private Label localisation;
    @FXML
    private Label email;
    @FXML
    private Label numtel;
    @FXML
    private ImageView cover;
    @FXML
    private Pane rtg;
    private Pane galpane;
    @FXML
    private ImageView logoimv;
    @FXML
    private TextArea textflo;
    @FXML
    private JFXToggleButton loveBTN;
    @FXML
    private ImageView loveIMG;
    
     // images in src folder.
   private static final double speed = 0.10;
	private static final String LEFT_ICON = "http://icons.iconarchive.com/icons/oxygen-icons.org/oxygen/48/Actions-arrow-left-icon.png";
	private static final String RIGHT_ICON = "http://icons.iconarchive.com/icons/oxygen-icons.org/oxygen/48/Actions-arrow-right-icon.png";
	private static final String IMAGE = "http://127.0.0.1/img/im1.jpg";
    @FXML
    private StackPane galpan;
    @FXML
    private ScrollPane main;
    List<String> l ;
    List<Horaire> lh ;
    List<Equipement> le ;
    @FXML
    private Pane rtg1;
    @FXML
    private HBox hBoxCat;
    @FXML
    private Label lundi;
    @FXML
    private Label jeudi;
    @FXML
    private Label mercredi;
    @FXML
    private Label mardi;
    @FXML
    private Label vendredi;
    @FXML
    private Label dimanche;
    @FXML
    private Label samedi;
    @FXML
    private Label courent;
    @FXML
    private Label timecurrent;
    @FXML
    private Pane horbase;
    @FXML
    private JFXCheckBox reservation;
    @FXML
    private JFXToggleButton saveBTN;
    @FXML
    private ImageView loveIMG1;
    @FXML
    private AnchorPane menucat;
    @FXML
    private PdfDecoderFX menudeco;
    @FXML
    private AnchorPane fb;
    @FXML
    private ImageView fbimg;
    @FXML
    private AnchorPane revpane;
    @FXML
    private VBox vbrev;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Propriete pro = new Propriete();
        lh= new ArrayList<>();
        le= new ArrayList<>();
         l = new ArrayList<>();
        try {
            // TODO
           pro =getPropById(PI.idp);
           l = getImgById(PI.idp);
           lh= getHoraireById(PI.idp);
           le= getEquipementById(PI.idp);
        } catch (SQLException ex) {
            Logger.getLogger(AffichPropController.class.getName()).log(Level.SEVERE, null, ex);
        }
        galpan.getStylesheets().add(getClass().getResource("test.css").toExternalForm());
        final ScrollPane scrollPane = new ScrollPane();
		scrollPane.setContent(addImages());
		scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
                
                
		/**
		 * Stackpane to stack images with Buttons
		 */
		
		galpan.getChildren().addAll(scrollPane, addButtons(scrollPane));
        
                
                //galpane.getChildren().add(stackPane);
                
           loveBTN.selectedProperty().addListener((p, ov, nv) -> {
        if(loveBTN.isSelected()){
            Image   l1  = new Image("http://127.0.0.1/img/heart.png", true);
        loveIMG.setImage(l1);
        }
                else{ 
             Image   l2  = new Image("http://127.0.0.1/img/heartoff.png", true);
        loveIMG.setImage(l2);
        }
    });
        
        
     
        Text text1 = new Text("Big italic red text");
        textflo.setWrapText(true);
        textflo.setText(pro.getDescription());
        Image  image  = new Image(pro.getCover(), true);
        Image  image2  = new Image(pro.getLogo(), true);
        titre.setText(pro.getTirte());
        slogan.setText(pro.getSlogan());
        numtel.setText(pro.getNumTel());
        email.setText(pro.getEmail());
        localisation.setText(pro.getAdresse());
        cover.setImage(image);
        logoimv.setImage(image2);
        Rating r =new Rating();
        for ( Horaire hr : lh) {
            
      
            Calendar now = Calendar.getInstance();
   

    String[] strDays = new String[] {  "dimanche","lundi", "mardi", "mercredi", "jeudi", "vendredi",
        "samedi"};
   
    if(hr.getJour().equals(strDays[now.get(Calendar.DAY_OF_WEEK) - 1])){
        if(hr.isState()){
            courent.setText("ouvert aujourd'hui :");
            timecurrent.setText(hr.getOuverture()+" - "+hr.getFermeture());
        }
        else  {
            courent.layoutXProperty().bind(horbase.widthProperty().subtract(r.widthProperty()).divide(2));
            courent.setTextFill(Color.RED);
            courent.setText("fermé aujourd'hui");
            timecurrent.setText("");
        }
    }
    
            
            if(hr.getJour().equals("lundi"))
            {
                if(hr.isState())
                lundi.setText(hr.getOuverture()+" - "+hr.getFermeture());
                 else lundi.setText("fermé");
            }
            if(hr.getJour().equals("mardi"))
            {
                if(hr.isState())
                mardi.setText(hr.getOuverture()+" - "+hr.getFermeture());
                 else mardi.setText("fermé");
            }
            if(hr.getJour().equals("mercredi"))
            {
                if(hr.isState())
                mercredi.setText(hr.getOuverture()+" - "+hr.getFermeture());
                 else mercredi.setText("fermé");
            }
            if(hr.getJour().equals("jeudi"))
            {
                if(hr.isState())
                jeudi.setText(hr.getOuverture()+" - "+hr.getFermeture());
                 else jeudi.setText("fermé");
            }
            if(hr.getJour().equals("vendredi"))
            {
                if(hr.isState())
                vendredi.setText(hr.getOuverture()+" - "+hr.getFermeture());
                 else vendredi.setText("fermé");
            }
            if(hr.getJour().equals("samedi"))
            {
                if(hr.isState())
                samedi.setText(hr.getOuverture()+" - "+hr.getFermeture());
                 else samedi.setText("fermé");
            }
            if(hr.getJour().equals("dimanche"))
            {
                if(hr.isState())
                dimanche.setText(hr.getOuverture()+" - "+hr.getFermeture());
                 else dimanche.setText("fermé");
            }
         
        }
        
        for ( Equipement eq : le) {
            System.out.println(eq.getNom().equals("Internet sans fil"));
        if(eq.getNom().equals("Internet sans fil")) {wifi.setSelected(true);System.out.println("wifi");}
        if(eq.getNom().equals("Sièges d'extérieur")) exterieur.setSelected(true);
        if(eq.getNom().equals("Stationnement dans la rue")) parkingRue.setSelected(true);
        if(eq.getNom().equals("Parking")) parking.setSelected(true);
        if(eq.getNom().equals("Autorisation de fumer")) fumeur.setSelected(true);
        if(eq.getNom().equals("Bon pour les enfants")) enfant.setSelected(true);
        if(eq.getNom().equals("Espace de travail convivial")) espaceTravail.setSelected(true);
        if(eq.getNom().equals("Ascenseur dans le bâtiment")) ascenseur.setSelected(true);
        if(eq.getNom().equals("Evénements")) event.setSelected(true);
        if(eq.getNom().equals("Cartes bancaires acceptées")) carte.setSelected(true);
        if(eq.getNom().equals("Accessible aux fauteuils roulants")) fauteuilRoulant.setSelected(true);
        if(eq.getNom().equals("Réservation")) reservation.setSelected(true);
        }
        
        initCheck();
        
        
           // menudeco=new PdfDecoderFX();
        Platform.runLater(() -> {
        try {
            menudeco.openPdfFile("C:\\canada.pdf");
            decodePage();
            System.out.println(menudeco.getNumberOfPages());
        } catch (PdfException e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
    });
      
       
        
        for(int i=0;i<4;i++){
        Image  imagec  = new Image("http://127.0.0.1/img/heart", true);
        //Image  imagec2  = new Image("http://127.0.0.1/img/heart", true);
        ImageView iv =new ImageView(imagec);
       // ImageView iv2 =new ImageView(imagec2);
        iv.setFitHeight(90);
        iv.setFitWidth(90);
        //iv2.setFitHeight(90);
        //iv2.setFitWidth(90);
        hBoxCat.setSpacing(2);
        hBoxCat.getChildren().add(iv);
        //hBoxCat.getChildren().add(iv2);
        }
        rtg.getChildren().add(r);
        r.layoutXProperty().bind(rtg.widthProperty().subtract(r.widthProperty()).divide(2));
        r.layoutYProperty().bind(rtg.heightProperty().subtract(r.heightProperty()).divide(3));
      
        
        ////
        fbimg.setOnMouseClicked(new EventHandler<MouseEvent>() {

				@Override
				public void handle(MouseEvent mouseEvent) {

					if (mouseEvent.getButton().equals(MouseButton.PRIMARY)) {

						if (mouseEvent.getClickCount() == 1) {
                                                    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("fbook.fxml"));
            Parent root = null;
                                                    try {
                                                        root = (Parent) fxmlLoader.load();
                                                    } catch (IOException ex) {
                                                        Logger.getLogger(AffichPropController.class.getName()).log(Level.SEVERE, null, ex);
                                                    }
              
            Stage stage = new Stage();
            stage.setScene(new Scene(root));  
            stage.show();

						}

					}
				}
			});
        //////
        for(int i=0;i<10;i++){
            Image  imagec  = new Image("http://127.0.0.1/img/im1", true);
        //Image  imagec2  = new Image("http://127.0.0.1/img/heart", true);
        ImageView iv =new ImageView(imagec);
        iv.setFitHeight(130);
        iv.setFitWidth(130);
        VBox v =new VBox(new Text("string1"),new TextArea("string2"));
            HBox hbox = new HBox(iv,v);
            vbrev.getChildren().add(hbox);
        }
        
        revpane.setPrefHeight(vbrev.getChildren().size() * 512);
        
        
    } 
    
    
    public HBox addImages() {
		HBox hBox = new HBox();
		hBox.setSpacing(10);
		// Adding icons of images to the HBox for creating the array of images

		for ( String stg : l) {
			final ImageView image = new ImageView(stg);
			image.setFitHeight(220);
			image.setPreserveRatio(true);
			image.setSmooth(true);
			image.setCache(true);

			//Adding FullScreen functionality on double Click !
			image.setOnMouseClicked(new EventHandler<MouseEvent>(){

            @Override
            public void handle(MouseEvent event) {
                System.out.println("img");
            }
        });
			hBox.getChildren().addAll(image);
		}

		return hBox;
	}
	
	//Adding Buttons to the ScrollPane
	private AnchorPane addButtons(final ScrollPane scrollPane)
	{
		Button right = new Button();
		right.setPrefSize(50, 150);
		right.setGraphic(new ImageView(new Image(RIGHT_ICON)));
		//Making the scroll move right
		right.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
		        scrollPane.setHvalue(scrollPane.getHvalue() + speed);
			}
		});
		
		Button left = new Button();
		left.setPrefSize(50, 150);
		left.setGraphic(new ImageView(new Image(LEFT_ICON)));
		//Making the scroll move left
		left.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
		        scrollPane.setHvalue(scrollPane.getHvalue() - speed);
			}
		});
		
		AnchorPane box = new AnchorPane();
		AnchorPane.setLeftAnchor(left, 1.0);
		AnchorPane.setRightAnchor(right, 1.0);
		box.getChildren().addAll(left,right);
		
		return box;
	}

    @FXML
    private void AddProp(ActionEvent event) throws IOException {
         FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("fbook.fxml"));
            Parent root = (Parent) fxmlLoader.load();
              
            Stage stage = new Stage();
            stage.setScene(new Scene(root));  
            stage.show();
    }

    @FXML
    private void Insc(ActionEvent event) {
    }

    @FXML
    private void SgnUp(ActionEvent event) {
    }
    
    private Propriete getPropById(int id) throws SQLException {
        
     ProprieteService ps = new ProprieteService();
     
        ResultSet  rs = ps.chercherPropriete(id);
        Propriete p = new Propriete();
        while(rs.next()){
        p.setTirte(rs.getString("titre"));
        p.setLogo("http://127.0.0.1/img/"+rs.getString("logo"));
        p.setSlogan(rs.getString("slogan"));
        p.setNumTel(rs.getString("numtel"));
        p.setEmail(rs.getString("email"));
        p.setAdresse(rs.getString("adresse"));
        p.setCover("http://127.0.0.1/img/"+rs.getString("cover"));
        p.setDescription(rs.getString("description"));
        }
       return p;
            
       
    }
    
    private List<String> getImgById(int id) throws SQLException {
        
     ImgService ps = new ImgService();
        List<String> ls = new ArrayList<>();
        ResultSet  rs = ps.afficherImg(id);
        Propriete p = new Propriete();
        while(rs.next()){
        ls.add("http://127.0.0.1/img/"+rs.getString("url"));
        }
       return ls;
            
       
    }
    
    private List<Horaire> getHoraireById(int id) throws SQLException {
        
     HoraireService ps = new HoraireService();
        List<Horaire> ls = new ArrayList<>();
        ResultSet  rs = ps.afficherHoraire(id);
        Propriete p = new Propriete();
        while(rs.next()){
           
        ls.add(new Horaire(rs.getString("jour"), rs.getTime("ouverture"), rs.getTime("fermeture"), rs.getBoolean("on_off")));
        }
       return ls;
            
       
    }
    
    private List<Equipement> getEquipementById(int id) throws SQLException {
        
     EquipementService ps = new EquipementService();
        List<Equipement> ls = new ArrayList<>();
        ResultSet  rs = ps.chercherEquipement(id);
        Propriete p = new Propriete();
        while(rs.next()){
           
        ls.add(new Equipement(rs.getString("nom")));
        }
       return ls;
            
       
    }
    
    private void initCheck() {
    wifi.setDisable(true);
        wifi.setStyle("-fx-opacity: 1");
         enfant.setDisable(true);
        enfant.setStyle("-fx-opacity: 1");
         carte.setDisable(true);
        carte.setStyle("-fx-opacity: 1");
         parking.setDisable(true);
        parking.setStyle("-fx-opacity: 1");
         parkingRue.setDisable(true);
        parkingRue.setStyle("-fx-opacity: 1");
         ascenseur.setDisable(true);
        ascenseur.setStyle("-fx-opacity: 1");
         fauteuilRoulant.setDisable(true);
        fauteuilRoulant.setStyle("-fx-opacity: 1");
         espaceTravail.setDisable(true);
        espaceTravail.setStyle("-fx-opacity: 1");
         reservation.setDisable(true);
        reservation.setStyle("-fx-opacity: 1");
         event.setDisable(true);
        event.setStyle("-fx-opacity: 1");
         exterieur.setDisable(true);
        exterieur.setStyle("-fx-opacity: 1");
         fumeur.setDisable(true);
        fumeur.setStyle("-fx-opacity: 1");
    }
    
    
    private void decodePage() {

    try {
        menudeco.setPageDisplayMode(1);
        menudeco.setPageParameters(1.0f, 1);
        menudeco.decodePage(1);
       // menudeco.setPageParameters(1.0f, 2);
        //menudeco.decodePage(2);
        menudeco.waitForDecodingToFinish();
        System.out.println(menudeco.getNumberOfPages());
    } catch (final Exception e) {
        e.printStackTrace();
        System.out.println(e.getMessage());
    }
}

    @FXML
    private void gofb(MouseEvent event) {
        System.out.println("fb");
    }

    private void sharefb(ActionEvent event) throws IOException {
         FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("fbook.fxml"));
            Parent root = (Parent) fxmlLoader.load();
              
            Stage stage = new Stage();
            stage.setScene(new Scene(root));  
            stage.show();
            
    }

    private void gofb(ActionEvent event) throws IOException {
         FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("fbook.fxml"));
            Parent root = (Parent) fxmlLoader.load();
              
            Stage stage = new Stage();
            stage.setScene(new Scene(root));  
            stage.show();
    }

    private void xx(ActionEvent event) {
        System.out.println("test");
    }

    
}

