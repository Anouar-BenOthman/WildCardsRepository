/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pi;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.controls.JFXTimePicker;
import com.jfoenix.controls.JFXToggleButton;
import entity.Categorie;
import entity.Equipement;
import entity.Horaire;
import entity.Propriete;
import entity.ReseauSocial;
import entity.Tag;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.Control;
import javafx.scene.control.Label;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.util.StringConverter;
import org.apache.commons.io.FilenameUtils;
import org.controlsfx.control.CheckComboBox;
import org.controlsfx.validation.Severity;
import org.controlsfx.validation.ValidationResult;
import org.controlsfx.validation.ValidationSupport;
import org.controlsfx.validation.Validator;
import service.CategorieService;
import service.EquipementService;
import service.HoraireService;
import service.ImgService;
import service.ProprieteService;
import service.ReseauSocialService;
import service.TagService;
import org.apache.commons.validator.routines.EmailValidator;
import org.apache.commons.validator.routines.UrlValidator;
import org.controlsfx.control.PopOver;

/**
 * FXML Controller class
 *
 * @author Nidhal
 */
public class MaptestController implements Initializable {

    @FXML
    private Button ajoutprp;
    @FXML
    private Button inscBTN;
    @FXML
    private Button connecBTN;
    @FXML
    private Button accBTN;
    @FXML
    private Button connecBTN1;
    @FXML
    private EmbeddedWebView embeddedWebView;
    @FXML
    private JFXTextField loginput;
    @FXML
    private JFXTextField latinput;
    @FXML
    private Button gomap;
    
    static String latetude;
    static String longitude;
    double lat;
    double lon;
    
    @FXML
    private Button longlatmap;
    @FXML
    private Button logoBTN;
    @FXML
    private Label logoLabel;
    @FXML
    private Button coverBTN;
    @FXML
    private Label coverLabel;
    @FXML
    private Button galeriBTN;
    @FXML
    private Label galeriLabel;
    @FXML
    private CheckComboBox<String> tagCombo; 
    
    final List<String> selectedItems = new ArrayList<>();
    final List<String> selectedItems2 = new ArrayList<>();
    private JFXComboBox<String> catgoriCombo;
    
    int e;
    
    static ValidationSupport support = new ValidationSupport();
    @FXML
    private CheckComboBox<String> comboCategorie;
    @FXML
    private JFXTextField emailInput;
    @FXML
    private JFXTextField titreInput;
    @FXML
    private JFXTextField sloganInput;
    @FXML
    private JFXTextArea descriptionInput;
    @FXML
    private JFXTextField emailOwnerInput;
    @FXML
    private JFXTextField numTelInput;
    @FXML
    private JFXTextField siteWebInput;
    @FXML
    private JFXTextField urlFacebookInput;
    @FXML
    private JFXTextField urlTwitterInput;
    @FXML
    private JFXTextField urlTumblrInput;
    @FXML
    private JFXTextField urlPrinterestInput;
    @FXML
    private JFXToggleButton facebookOnOff;
    @FXML
    private JFXToggleButton twitterOnOff;
    @FXML
    private JFXToggleButton tumblrOnOff;
    @FXML
    private JFXToggleButton printerestOnOff;
    @FXML
    private JFXTimePicker lundi1;
    @FXML
    private JFXTimePicker lundi2;
    @FXML
    private JFXTimePicker mardi1;
    @FXML
    private JFXTimePicker mardi2;
    @FXML
    private JFXTimePicker mercredi1;
    @FXML
    private JFXTimePicker mercredi2;
    @FXML
    private JFXTimePicker jeudi1;
    @FXML
    private JFXTimePicker jeudi2;
    @FXML
    private JFXTimePicker vendredi1;
    @FXML
    private JFXTimePicker vendredi2;
    @FXML
    private JFXTimePicker samedi1;
    @FXML
    private JFXTimePicker samedi2;
    @FXML
    private JFXTimePicker dimanche1;
    @FXML
    private JFXTimePicker dimanche2;
    @FXML
    private JFXToggleButton lundiOnOff;
    @FXML
    private JFXToggleButton mardiOnOff;
    @FXML
    private JFXToggleButton mercrediOnOff;
    @FXML
    private JFXToggleButton jeudiOnOff;
    @FXML
    private JFXToggleButton vendrediOnOff;
    @FXML
    private JFXToggleButton samediOnOff;
    @FXML
    private JFXToggleButton dimancheOnOff;
    @FXML
    private JFXCheckBox parking;
    @FXML
    private JFXCheckBox fumeur;
    @FXML
    private JFXCheckBox wifi;
    @FXML
    private JFXCheckBox ascenseur;
    @FXML
    private JFXCheckBox carte;
    @FXML
    private JFXCheckBox event;
    @FXML
    private JFXCheckBox espaceTravail;
    @FXML
    private JFXCheckBox parkingRue;
    @FXML
    private JFXCheckBox fauteuilRoulant;
    @FXML
    private JFXCheckBox enfant;
    @FXML
    private JFXCheckBox exterieur;
    @FXML
    private JFXCheckBox reservation;
    @FXML
    private Button submitBTN;
    @FXML
    private JFXTextField adresseInput;
    @FXML
    private Button menuBTN;
    @FXML
    private Label menuLabel;
    @FXML
    private JFXTextField tagInput;
    @FXML
    private Button tagAddBTN;
    
    ObservableList<CheckMenuItem> items;
    ObservableList<CheckMenuItem> items2;
    List<String> sFiles=new ArrayList<>();

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initHoraire();
        test();
        initCombo();
        valid();

        
         gomap.setOnAction(new EventHandler<ActionEvent>() {

                @Override
                public void handle(ActionEvent arg0) {
                    lat = Double.parseDouble(latinput.getText());
                    lon = Double.parseDouble(loginput.getText());

                    
                    embeddedWebView.execstring("" +
                        "window.lat = " + lat + ";" +
                        "window.lon = " + lon + ";" +
                        "document.goToLocation(window.lat, window.lon);"
                    );
                }
            });
         longlatmap.setOnAction(e->{
         embeddedWebView.execstring("tes();");
         latinput.setText(latetude);
         loginput.setText(longitude);
         
         });
        
         
        }

    @FXML
    private void AddProp(ActionEvent event) throws SQLException {
       /*  if(support.isInvalid())
       {
           System.out.println("valide");
           Notifications.create()
              .title("ERROR")
              .text("Mettez le curseur sur cette icone se situant en bas à\n"
                      + "gauche sur les chaps irronés pour avoir des "
                      + "information sur l'erreure.")
              .showError();
          
      
       }
       else System.out.println("invalide");
        */
       ProprieteService ps = new ProprieteService();
        EquipementService es = new EquipementService();
        HoraireService hs= new HoraireService();
        ReseauSocialService r= new ReseauSocialService();
        TagService ts =new TagService();
        ImgService is= new ImgService();
        CategorieService cs = new CategorieService();
        
        
         Propriete p = new Propriete(emailInput.getText(), titreInput.getText()
                , sloganInput.getText(), descriptionInput.getText(),
                logoLabel.getText(), coverLabel.getText(),emailOwnerInput.getText()
                , numTelInput.getText(), siteWebInput.getText(), adresseInput.getText()
                ,Float.parseFloat(latinput.getText()),Float.parseFloat(loginput.getText()));
        
        ps.ajouterPropriete(p);
        ResultSet x = ps.indice();
        int ind=0;
        while(x.next()){
            ind=x.getInt("id");
        }
        // Declaration des categories
        
        for(String s :comboCategorie.getCheckModel().getCheckedItems())
        {
        Categorie c1 = new Categorie(s,ind );
        cs.ajouterCategorie(c1, ind);
        }
        
        
       
        
        // Declaration des horaires
        
        if(lundiOnOff.isSelected()){
        Horaire h1 = new Horaire("lundi", Time.valueOf(lundi1.getEditor().getText()), Time.valueOf(lundi2.getEditor().getText()), true, 1);
        hs.ajouterHoraire(h1, ind);
        }
        else{
        Horaire h1 = new Horaire("lundi",null, null, false, 1);
        hs.ajouterHoraire(h1, ind);
        }
        
        if(mardiOnOff.isSelected()){
        Horaire h1 = new Horaire("mardi", Time.valueOf(mardi1.getEditor().getText()), Time.valueOf(mardi2.getEditor().getText()), true, 1);
        hs.ajouterHoraire(h1, ind);
        }
        else{
        Horaire h1 = new Horaire("mardi",null, null, false, 1);
        hs.ajouterHoraire(h1, ind);
        }
        if(mercrediOnOff.isSelected()){
        Horaire h1 = new Horaire("mercredi", Time.valueOf(mercredi1.getEditor().getText()), Time.valueOf(mercredi2.getEditor().getText()), true, 1);
        hs.ajouterHoraire(h1, ind);
        }
        else{
        Horaire h1 = new Horaire("mercredi",null, null, false, 1);
        hs.ajouterHoraire(h1, ind);
        }
        
        if(jeudiOnOff.isSelected()){
        Horaire h1 = new Horaire("jeudi", Time.valueOf(jeudi1.getEditor().getText()), Time.valueOf(jeudi2.getEditor().getText()), true, 1);
        hs.ajouterHoraire(h1, ind);
        }
        else{
        Horaire h1 = new Horaire("jeudi",null, null, false, 1);
        hs.ajouterHoraire(h1, ind);
        }
        
        if(vendrediOnOff.isSelected()){
        Horaire h1 = new Horaire("vendredi", Time.valueOf(vendredi1.getEditor().getText()), Time.valueOf(vendredi2.getEditor().getText()), true, 1);
        hs.ajouterHoraire(h1, ind);
        }
        else{
        Horaire h1 = new Horaire("vendredi",null, null, false, 1);
        hs.ajouterHoraire(h1, ind);
        }
        
        if(samediOnOff.isSelected()){
        Horaire h1 = new Horaire("samedi", Time.valueOf(samedi1.getEditor().getText()), Time.valueOf(samedi2.getEditor().getText()), true, 1);
        hs.ajouterHoraire(h1, ind);
        }
        else{
        Horaire h1 = new Horaire("samedi",null, null, false, 1);
        hs.ajouterHoraire(h1, ind);
        }
        
        if(dimancheOnOff.isSelected()){
        Horaire h1 = new Horaire("dimanche", Time.valueOf(dimanche1.getEditor().getText()), Time.valueOf(dimanche2.getEditor().getText()), true, 1);
        hs.ajouterHoraire(h1, ind);
        }
        else{
        Horaire h1 = new Horaire("dimanche",null, null, false, 1);
        hs.ajouterHoraire(h1, ind);
        }
       
        
        
        // Declaration des equipements
        if(parking.isSelected()){
        Equipement e1 = new Equipement(parking.getText(), 1);
        es.ajouterEquipement(e1, ind);
        }
        if(parkingRue.isSelected()){
        Equipement e1 = new Equipement(parkingRue.getText(), 1);
        es.ajouterEquipement(e1, ind);
        }
        if(ascenseur.isSelected()){
        Equipement e1 = new Equipement(ascenseur.getText(), 1);
        es.ajouterEquipement(e1, ind);
        }
        if(enfant.isSelected()){
        Equipement e1 = new Equipement(enfant.getText(), 1);
        es.ajouterEquipement(e1, ind);
        }
        if(reservation.isSelected()){
        Equipement e1 = new Equipement(reservation.getText(), 1);
        es.ajouterEquipement(e1, ind);
        }
        if(carte.isSelected()){
        Equipement e1 = new Equipement(carte.getText(), 1);
        es.ajouterEquipement(e1, ind);
        }
        if(wifi.isSelected()){
        Equipement e1 = new Equipement(wifi.getText(), 1);
        es.ajouterEquipement(e1, ind);
        }
        if(espaceTravail.isSelected()){
        Equipement e1 = new Equipement(espaceTravail.getText(), 1);
        es.ajouterEquipement(e1, ind);
        }
        if(this.event.isSelected()){
        Equipement e1 = new Equipement(this.event.getText(), 1);
        es.ajouterEquipement(e1, ind);
        }
        if(fauteuilRoulant.isSelected()){
        Equipement e1 = new Equipement(fauteuilRoulant.getText(), 1);
        es.ajouterEquipement(e1, ind);
        }
        if(fumeur.isSelected()){
        Equipement e1 = new Equipement(fumeur.getText(), 1);
        es.ajouterEquipement(e1, ind);
        }
        if(exterieur.isSelected()){
        Equipement e1 = new Equipement(exterieur.getText(), 1);
        es.ajouterEquipement(e1, ind);
        }
       
        
       
        // Declaration des tags
       
        for(String s :tagCombo.getCheckModel().getCheckedItems())
        {
        Tag t1 = new Tag(s, 1);
        ts.ajouterTag(t1, ind);
        }
        
        
       
        // Declaration des reseaux sociaux
        if(facebookOnOff.isSelected()){
        ReseauSocial r1 = new ReseauSocial("Facebook",urlFacebookInput.getText(), 1);
        r.ajouterReseau(r1, ind);
        }
        if(twitterOnOff.isSelected()){
        ReseauSocial r2 = new ReseauSocial("Twitter",urlTwitterInput.getText(), 1);
        r.ajouterReseau(r2, ind);
        }
        if(tumblrOnOff.isSelected()){
        ReseauSocial r3 = new ReseauSocial("Tumblr",urlTumblrInput.getText(), 1);
        r.ajouterReseau(r3, ind);
        }
        if(printerestOnOff.isSelected()){
        ReseauSocial r4 = new ReseauSocial("Printerest",urlPrinterestInput.getText(), 1);
        r.ajouterReseau(r4, ind);
        }
        
        // Declaratio de gallery
        if(!sFiles.isEmpty()){
        for(String f : sFiles){
        is.ajouterImg(f, ind);
        }
        }
        
       PI.idp=ind; 
        
        try {
    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXML2.fxml"));
            Parent root = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));  
            stage.show();
            PI.stg.close();
            PI.stg = stage;
    } catch(Exception e) {
       e.printStackTrace();
      }
    }

    @FXML
    private void Insc(ActionEvent event) {
        Node source = (Node) event.getSource();
    Window theStage = source.getScene().getWindow();

        PopOver popover = new PopOver();
        popover.setContentNode(new JFXButton("test"));
       popover.show(inscBTN);
    }

    @FXML
    private void SgnUp(ActionEvent event) {
    }

    @FXML
    private void GoHome(ActionEvent event) {
          try {
    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXML2.fxml"));
            Parent root = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));  
            stage.show();
            PI.stg.close();
            PI.stg = stage;
    } catch(Exception e) {
       e.printStackTrace();
      }
    }

    @FXML
    private void gomp(ActionEvent event) {
    }

    @FXML
    private void setlonglat(ActionEvent event) {
    }

    @FXML
    private void logoChoose(ActionEvent event) throws IOException {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(
         new ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"));
        File selectedFile = fileChooser.showOpenDialog(null);
        if (selectedFile != null) {
            
            Random rand = new Random();

            int  n = rand.nextInt(1000) + 1;
            String s = String.valueOf(n)+"."+ FilenameUtils.getExtension(selectedFile.getName());
            File dest = new File("C:\\\\wamp64\\\\www\\\\img\\"+s);
            Files.copy(selectedFile.toPath(),dest.toPath(),REPLACE_EXISTING);
            logoLabel.setText(s);
        }
        else {

            System.out.println("File selection cancelled.");
        }

    }

    @FXML
    private void coverChoose(ActionEvent event) throws IOException {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(
         new ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"));
        File selectedFile = fileChooser.showOpenDialog(null);
        if (selectedFile != null) {
            Random rand = new Random();

            int  n = rand.nextInt(1000) + 1;
            String s = String.valueOf(n)+"."+ FilenameUtils.getExtension(selectedFile.getName());
            File dest = new File("C:\\\\wamp64\\\\www\\\\img\\"+s);
            Files.copy(selectedFile.toPath(),dest.toPath(),REPLACE_EXISTING);
            coverLabel.setText(s);
        }
        else {

            System.out.println("File selection cancelled.");
        }
    }

    @FXML
    private void galeriChoose(ActionEvent event) throws IOException {
        FileChooser fileChooser = new FileChooser();
//fileChooser.setTitle("Select PDF files");
//fileChooser.setInitialDirectory(new File("X:\\testdir\\two"));
fileChooser.getExtensionFilters().addAll(
        new ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"));
Node source = (Node) event.getSource();
    Window theStage = source.getScene().getWindow();
List<File> selectedFiles = fileChooser.showOpenMultipleDialog(theStage);

if (selectedFiles != null) {

    System.out.println("PDF Files selected [" + selectedFiles.size() + "]: " + selectedFiles.get(0).getName() + "..");
    String s="";
    for(File f :selectedFiles){
         Random rand = new Random();

            int  n = rand.nextInt(1000) + 1;
            String st = String.valueOf(n)+"."+ FilenameUtils.getExtension(f.getName());
            File dest = new File("C:\\\\wamp64\\\\www\\\\img\\"+st);
            Files.copy(f.toPath(),dest.toPath(),REPLACE_EXISTING);
            s=s+st+"  ";
            sFiles.add(st);
    }
    galeriLabel.setText(s);
}
else {
    System.out.println("PDF file selection cancelled.");
}
//sFiles=selectedFiles;
    }

    @FXML
    private void menuChoose(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(
         new ExtensionFilter("PDF Files", "*.pdf"));
        File selectedFile = fileChooser.showOpenDialog(null);
        if (selectedFile != null) {
            menuLabel.setText(selectedFile.getName());
        }
        else {

            System.out.println("File selection cancelled.");
        }
    }

        
    private void initHoraire(){
        lundi1.setConverter(new StringConverter<LocalTime>() {
            private DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss");
            @Override
            public String toString(LocalTime object) {
                 if(object==null)
            return "";
        return dtf.format(object);
            }

            @Override
            public LocalTime fromString(String string) {
                if(string==null || string.trim().isEmpty())
        {
            return null;
        }
        return LocalTime.parse(string,dtf);
            }
          
        });
        lundi2.setConverter(new StringConverter<LocalTime>() {
            private DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss");
            @Override
            public String toString(LocalTime object) {
                 if(object==null)
            return "";
        return dtf.format(object);
            }

            @Override
            public LocalTime fromString(String string) {
                if(string==null || string.trim().isEmpty())
        {
            return null;
        }
        return LocalTime.parse(string,dtf);
            }
          
        });
        lundi1.setIs24HourView(true);
         lundi2.setIs24HourView(true);
        lundi1.setDisable(true);
        lundi2.setDisable(true);
        mardi1.setDisable(true);
        mardi2.setDisable(true);
        mercredi1.setDisable(true);
        mercredi2.setDisable(true);
        jeudi1.setDisable(true);
        jeudi2.setDisable(true);
        vendredi1.setDisable(true);
        vendredi2.setDisable(true);
        samedi1.setDisable(true);
        samedi2.setDisable(true);
        dimanche1.setDisable(true);
        dimanche2.setDisable(true);
        urlFacebookInput.setDisable(true);
        urlPrinterestInput.setDisable(true);
        urlTumblrInput.setDisable(true);
        urlTwitterInput.setDisable(true);
        
        
}
    private void test(){
     lundiOnOff.selectedProperty().addListener((p, ov, nv) -> {
        if(lundiOnOff.isSelected()){
            lundiOnOff.setText("Ouvert");
            lundi1.setDisable(false);
        lundi2.setDisable(false);
        }
                else{ 
            lundiOnOff.setText("Fermé");
            lundi1.setDisable(true);
            lundi2.setDisable(true);
        }
    });
     
     lundiOnOff.selectedProperty().addListener((p, ov, nv) -> {
        if(lundiOnOff.isSelected()){
            lundiOnOff.setText("Ouvert");
            lundi1.setDisable(false);
        lundi2.setDisable(false);
        }
                else{ 
            lundiOnOff.setText("Fermé");
            lundi1.setDisable(true);
            lundi2.setDisable(true);
        }
    });
     
     mardiOnOff.selectedProperty().addListener((p, ov, nv) -> {
        if(mardiOnOff.isSelected()){
            mardiOnOff.setText("Ouvert");
            mardi1.setDisable(false);
        mardi2.setDisable(false);
        }
                else{ 
            mardiOnOff.setText("Fermé");
            mardi1.setDisable(true);
            mardi2.setDisable(true);
        }
    });
     
     mercrediOnOff.selectedProperty().addListener((p, ov, nv) -> {
        if(mercrediOnOff.isSelected()){
            mercrediOnOff.setText("Ouvert");
            mercredi1.setDisable(false);
        mercredi2.setDisable(false);
        }
                else{ 
            mercrediOnOff.setText("Fermé");
            mercredi1.setDisable(true);
            mercredi2.setDisable(true);
        }
    });
     
     jeudiOnOff.selectedProperty().addListener((p, ov, nv) -> {
        if(jeudiOnOff.isSelected()){
            jeudiOnOff.setText("Ouvert");
            jeudi1.setDisable(false);
        jeudi2.setDisable(false);
        }
                else{ 
            jeudiOnOff.setText("Fermé");
            jeudi1.setDisable(true);
            jeudi2.setDisable(true);
        }
    });
     
     vendrediOnOff.selectedProperty().addListener((p, ov, nv) -> {
        if(vendrediOnOff.isSelected()){
            vendrediOnOff.setText("Ouvert");
            vendredi1.setDisable(false);
        vendredi2.setDisable(false);
        }
                else{ 
            vendrediOnOff.setText("Fermé");
            vendredi1.setDisable(true);
            vendredi2.setDisable(true);
        }
    });
     
     samediOnOff.selectedProperty().addListener((p, ov, nv) -> {
        if(samediOnOff.isSelected()){
            samediOnOff.setText("Ouvert");
            samedi1.setDisable(false);
        samedi2.setDisable(false);
        }
                else{ 
            samediOnOff.setText("Fermé");
            samedi1.setDisable(true);
            samedi2.setDisable(true);
        }
    });
     
     dimancheOnOff.selectedProperty().addListener((p, ov, nv) -> {
        if(dimancheOnOff.isSelected()){
            dimancheOnOff.setText("Ouvert");
            dimanche1.setDisable(false);
        dimanche2.setDisable(false);
        }
                else{ 
            dimancheOnOff.setText("Fermé");
            dimanche1.setDisable(true);
            dimanche2.setDisable(true);
        }
    });
     
     
       facebookOnOff.selectedProperty().addListener((p, ov, nv) -> {
        if(facebookOnOff.isSelected()){
           
            urlFacebookInput.setDisable(false);
        
        }
                else{ 
           
            urlFacebookInput.setDisable(true);
            
        }
    });   
     
       twitterOnOff.selectedProperty().addListener((p, ov, nv) -> {
        if(twitterOnOff.isSelected()){
           
            urlTwitterInput.setDisable(false);
        
        }
                else{ 
           
            urlTwitterInput.setDisable(true);
            
        }
    });   
       
       tumblrOnOff.selectedProperty().addListener((p, ov, nv) -> {
        if(tumblrOnOff.isSelected()){
           
            urlTumblrInput.setDisable(false);
        
        }
                else{ 
           
            urlTumblrInput.setDisable(true);
            
        }
    });   
       
       printerestOnOff.selectedProperty().addListener((p, ov, nv) -> {
        if(printerestOnOff.isSelected()){
           
            urlPrinterestInput.setDisable(false);
        
        }
                else{ 
           
            urlPrinterestInput.setDisable(true);
            
        }
    });   
     
    }
    
    private void initCombo(){
       ObservableList<String> options = 
        FXCollections.observableArrayList(
        "Celio",
        "Zara",
        "Jules"
    );
 
    items =FXCollections.observableArrayList(
                new CheckMenuItem("Apfel"),
                new CheckMenuItem("Banane"),
                new CheckMenuItem("Birne"),
                new CheckMenuItem("Kiwi")
      );
    
    items2 =FXCollections.observableArrayList(
                new CheckMenuItem("Apfel"),
                new CheckMenuItem("Banane"),
                new CheckMenuItem("Birne"),
                new CheckMenuItem("Kiwi")
      );
    
    
    
    comboCategorie.getStylesheets().add("pi/fxml1.css");
    comboCategorie.getItems().addAll("test","azerty");
   
    tagCombo.getStylesheets().add("pi/fxml1.css");
    tagCombo.getItems().addAll("test","azerty","qwerty");
        
        
       
    }
    
    private void valid(){
           
    Validator<String> validator = new Validator<String>()
    {
      @Override
      public ValidationResult apply( Control control, String value )
      {
        boolean condition =
            value != null
                ? value
                    .isEmpty()
                : value == null;

        System.out.println( condition );
        if(!condition)e=1;

        return ValidationResult.fromMessageIf( control, "Ce champ est obligatoire", Severity.ERROR, condition );
      }

         
    };
    
    
    
    Validator<String> mailvalidator = new Validator<String>()
    {
      @Override
      public ValidationResult apply( Control control, String value )
      {
        boolean condition =
            value != null
                ? !isValidMail(value)
                : value == null;

        System.out.println( condition );
        if(!condition)e=1;

        return ValidationResult.fromMessageIf( control, "Email incorrect", Severity.ERROR, condition );
      }

      

         
    };
    
     Validator<String> websitevalidator = new Validator<String>()
    {
      @Override
      public ValidationResult apply( Control control, String value )
      {
        boolean condition = !isValidWebSite(value);
        
        return ValidationResult.fromMessageIf( control, "URL incorrect", Severity.ERROR, condition );
      }

      

         
    };
    
    Validator<String> numtelvalidator = new Validator<String>()
    {
      @Override
      public ValidationResult apply( Control control, String value )
      {
        boolean condition =
            value != null
                ? !value.matches("^[0-9]{8}$")
                : value == null;

        System.out.println( condition );
        if(!condition)e=1;

        return ValidationResult.fromMessageIf( control, "numéro de telephone incorrect", Severity.ERROR, condition );
      }

      

         
    };

    
     Validator<String> facebookvalidator = new Validator<String>()
    {
      @Override
      public ValidationResult apply( Control control, String value )
      {
          boolean condition;
          if (value==null || "".equals(value))
		condition = false;
          else
        condition = !value.matches("((http|https)://)?(www[.])?facebook.com/.+");
         
        return ValidationResult.fromMessageIf( control, "l'URL de votre compte est invalide", Severity.ERROR, condition );
      }

      

         
    };
     
      Validator<String> twittervalidator = new Validator<String>()
    {
      @Override
      public ValidationResult apply( Control control, String value )
      {
          boolean condition;
          if (value==null || "".equals(value))
		condition = false;
          else
        condition = !value.matches("((http|https)://)?(www[.])?twitter.com/.+");
         
        return ValidationResult.fromMessageIf( control, "l'URL de votre compte est invalide", Severity.ERROR, condition );
      }

      

         
    };
      
        Validator<String> tumblrvalidator = new Validator<String>()
    {
      @Override
      public ValidationResult apply( Control control, String value )
      {
          boolean condition;
          if (value==null || "".equals(value))
		condition = false;
          else
        condition = !value.matches("((http|https)://)?(www[.])?tumblr.com/.+");
         
        return ValidationResult.fromMessageIf( control, "l'URL de votre compte est invalide", Severity.ERROR, condition );
      }

      

         
    };
        
          Validator<String> pinterestvalidator = new Validator<String>()
    {
      @Override
      public ValidationResult apply( Control control, String value )
      {
          boolean condition;
          if (value==null || "".equals(value))
		condition = false;
          else
        condition = !value.matches("((http|https)://)?(www[.])?pinterest.com/.+");
         
        return ValidationResult.fromMessageIf( control, "l'URL de votre compte est invalide", Severity.ERROR, condition );
      }

      

         
    };

    
    support.registerValidator( titreInput, false, validator );
    support.registerValidator( sloganInput, false, validator );
    support.registerValidator( descriptionInput, false, validator );
    support.registerValidator( numTelInput, false, numtelvalidator );
    support.registerValidator( emailInput, false, mailvalidator );
    support.registerValidator( siteWebInput, false, websitevalidator );
    support.registerValidator( emailOwnerInput, false, mailvalidator );
    support.registerValidator( urlFacebookInput, false, facebookvalidator );
    support.registerValidator( urlTwitterInput, false, twittervalidator );
    support.registerValidator( urlPrinterestInput, false, pinterestvalidator );
    support.registerValidator( urlTumblrInput, false, tumblrvalidator );
        System.out.println("state "+support.isInvalid());
    
         
    
    }


    @FXML
    private void addTag(ActionEvent event) {
        if(!tagInput.getText().equals("") && !tagCombo.getItems().contains(tagInput.getText()) ){
        tagCombo.getItems().add(tagInput.getText());
        tagCombo.getCheckModel().check(tagInput.getText());
        tagInput.setText("");
        }
    }
    
    
    private boolean isValidMail(String email) {
	if (email == null || "".equals(email))
		return false;
	
	email = email.trim();
	
	EmailValidator ev = EmailValidator.getInstance();
	return ev.isValid(email);
	
}
    
    private boolean isValidWebSite(String url) {
	if (url==null || "".equals(url))
		return true;
	
	url = url.trim();
	
	UrlValidator ev = UrlValidator.getInstance();
	return ev.isValid(url);
	
}
    

}

