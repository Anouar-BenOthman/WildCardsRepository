/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pi;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXDrawer;
import com.jfoenix.controls.JFXHamburger;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.transitions.hamburger.HamburgerBackArrowBasicTransition;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;

/**
 * FXML Controller class
 *
 * @author Nidhal
 */
public class AccLogController implements Initializable {

    @FXML
    private Button ajoutprp;
    @FXML
    private JFXTextField rechercheInMag;
    @FXML
    private JFXTextField local;
    @FXML
    private JFXComboBox<?> comboMag;
    @FXML
    private JFXButton rechMagBTN;
    @FXML
    private JFXTextField rechercheInEv;
    @FXML
    private JFXTextField localEv;
    @FXML
    private JFXComboBox<?> comboEv;
    @FXML
    private JFXButton rechEvBTN;
    @FXML
    private JFXDrawer draw;
    @FXML
    private JFXHamburger hamberg;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            VBox box = FXMLLoader.load(getClass().getResource("SidePanelContent.fxml"));
            draw.setSidePane(box);
        } catch (IOException ex) {
           // Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
        HamburgerBackArrowBasicTransition transition = new HamburgerBackArrowBasicTransition(hamberg);
        transition.setRate(-1);
        hamberg.addEventHandler(MouseEvent.MOUSE_PRESSED,(e)->{
            transition.setRate(transition.getRate()*-1);
            transition.play();
            
            if(draw.isShown())
            {
                draw.close();
            }else
                draw.open();
        });
    }    

    @FXML
    private void AddProp(ActionEvent event) {
    }


    @FXML
    private void rechInMag(ActionEvent event) {
    }

    @FXML
    private void localInMag(ActionEvent event) {
    }

    @FXML
    private void rechMag(ActionEvent event) {
    }

    @FXML
    private void rechInEv(ActionEvent event) {
    }

    @FXML
    private void localInEv(ActionEvent event) {
    }

    @FXML
    private void rechEv(ActionEvent event) {
    }
    
}
