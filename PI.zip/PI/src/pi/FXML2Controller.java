/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pi;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Control;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.scene.web.WebView;
import javafx.stage.Stage;
import org.controlsfx.control.textfield.TextFields;
import org.controlsfx.validation.Severity;
import org.controlsfx.validation.ValidationResult;
import org.controlsfx.validation.ValidationSupport;
import org.controlsfx.validation.Validator;

/**
 * FXML Controller class
 *
 * @author Nidhal
 */
public class FXML2Controller implements Initializable {

    @FXML
    private Button ajoutprp;
    @FXML
    private Button connecBTN;
    @FXML
    private JFXTextField rechercheInMag;
    @FXML
    private JFXComboBox<String> comboMag;
    
    
    private final Image IMAGE_RUBY  = new Image("https://www.shareicon.net/data/32x32/2017/01/14/871141_fork_512x512.png");
    private final Image IMAGE_APPLE  = new Image("https://www.shareicon.net/data/32x32/2017/01/14/871092_tea_512x512.png");
    private final Image IMAGE_VISTA  = new Image("https://www.shareicon.net/data/32x32/2016/06/21/611911_rocket_128x128.png");
    private final Image IMAGE_TWITTER = new Image("https://www.shareicon.net/data/32x32/2016/06/22/612003_trophy_128x128.png");
    private final Image Shop = new Image("https://www.shareicon.net/data/32x32/2016/09/09/827456_commerce_512x512.png");
    private final Image VN = new Image("https://www.shareicon.net/data/32x32/2016/04/16/494513_martini_200x200.png");

    private Image[] listOfImages = {IMAGE_RUBY, IMAGE_APPLE, IMAGE_VISTA, IMAGE_TWITTER,Shop,VN};
    @FXML
    private JFXTextField local;
    @FXML
    private JFXButton rechMagBTN;
    @FXML
    private JFXTextField rechercheInEv;
    @FXML
    private JFXTextField localEv;
    @FXML
    private JFXComboBox<?> comboEv;
    @FXML
    private JFXButton rechEvBTN;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        TextFields.bindAutoCompletion(
            rechercheInMag,
            "Hey", "Hello", "Hello World", "Apple", "Cool", "Costa", "Cola", "Coca Cola");
        
         ObservableList<String> options = 
        FXCollections.observableArrayList(
        "Aliment",
        "Café",
        "Top",
        "Shopping",
        "Vie nocturne",
        "Tendance"
    );
         comboMag.setItems(options);
         
         comboMag.setCellFactory(param -> new ListCell<String>() {
            private ImageView imageView = new ImageView();
            @Override
            public void updateItem(String name, boolean empty) {
                super.updateItem(name, empty);
                if (empty) {
                    setText(null);
                    setGraphic(null);
                } else {
                    if(name.equals("Aliment"))
                        imageView.setImage(listOfImages[0]);
                    else if(name.equals("Café"))
                        imageView.setImage(listOfImages[1]);
                    else if(name.equals("Tendance"))
                        imageView.setImage(listOfImages[2]);
                    else if(name.equals("Top"))
                        imageView.setImage(listOfImages[3]);
                    else if(name.equals("Shopping"))
                        imageView.setImage(listOfImages[4]);
                    else if(name.equals("Vie nocturne"))
                        imageView.setImage(listOfImages[5]);
                    setText(name);
                    setGraphic(imageView);
                }
            }
        });
         
         
    /* ValidationSupport support = new ValidationSupport();

    Validator<String> validator = new Validator<String>()
    {
      @Override
      public ValidationResult apply( Control control, String value )
      {
        boolean condition =
            value != null
                ? !value
                    .matches(
                        "[\\x00-\\x20]*[+-]?(((((\\p{Digit}+)(\\.)?((\\p{Digit}+)?)([eE][+-]?(\\p{Digit}+))?)|(\\.((\\p{Digit}+))([eE][+-]?(\\p{Digit}+))?)|(((0[xX](\\p{XDigit}+)(\\.)?)|(0[xX](\\p{XDigit}+)?(\\.)(\\p{XDigit}+)))[pP][+-]?(\\p{Digit}+)))[fFdD]?))[\\x00-\\x20]*" )
                : value == null;

        System.out.println( condition );

        return ValidationResult.fromMessageIf( control, "not a number", Severity.WARNING, condition );
      }

         
    };

    support.registerValidator( rechercheInMag, true, validator );*/
    }    
    
    

    @FXML
    private void AddProp(ActionEvent event) {
                try {
    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("maptest.fxml"));
            Parent root = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));  
            stage.show();
            PI.stg.close();
            PI.stg = stage;
    } catch(Exception e) {
       e.printStackTrace();
      }
        
    }


    @FXML
    private void SgnUp(ActionEvent event) {
         try {
    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("AccLog.fxml"));
            Parent root = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));  
            stage.show();
            PI.stg.close();
            PI.stg = stage;
    } catch(Exception e) {
       e.printStackTrace();
      }
    }

    @FXML
    private void rechInMag(ActionEvent event) {
    }

    @FXML
    private void localInMag(ActionEvent event) {
    }

    @FXML
    private void rechMag(ActionEvent event) {
          try {
    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("rechercheProp.fxml"));
            Parent root = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));  
            stage.show();
            PI.stg.close();
            PI.stg = stage;
    } catch(Exception e) {
       e.printStackTrace();
      }
    }

    @FXML
    private void rechInEv(ActionEvent event) {
    }

    @FXML
    private void localInEv(ActionEvent event) {
    }

    @FXML
    private void rechEv(ActionEvent event) {
    }

    
}
