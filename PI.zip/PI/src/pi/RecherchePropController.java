/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pi;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXTextField;
import entity.Propriete;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.util.Callback;
import org.controlsfx.control.PopOver;
import org.controlsfx.control.Rating;
import service.ProprieteService;

/**
 * FXML Controller class
 *
 * @author Nidhal
 */
public class RecherchePropController implements Initializable {
int i = 1;
static Propriete p = new Propriete();
    @FXML
    private Button ajoutprp;
    @FXML
    private Button inscBTN;
    @FXML
    private Button connecBTN;
    @FXML
    private EmbeddedWebView embeddedWebView;
    @FXML
    private ListView<CustomThing> propList;
    @FXML
    private Button prixBTN;
    @FXML
    private Button ouvertBTN;
    @FXML
    private Button equipementBTN;
    @FXML
    private JFXTextField rechInput;
    @FXML
    private JFXTextField localInput;
    @FXML
    private Button rechBTN;
    @FXML
    private Button promoBTN;
    ProprieteService ps = new ProprieteService();
    @FXML
    private void rech(ActionEvent event) throws SQLException {
        embeddedWebView.execstring("clearOverlays();");
        propList.getItems().clear();
        UpdateableListViewSkin<CustomThing> skin = new UpdateableListViewSkin<>(this.propList);
        this.propList.setSkin(skin);
       ((UpdateableListViewSkin) propList.getSkin()).refresh();
        ResultSet rset = ps.chercherPropriete(rechInput.getText());
        int j =1;
        while(rset.next()){
        propList.getItems().add(new CustomThing(rset.getInt("id"),j+". "+rset.getString("titre"),
                new Rating(), "http://127.0.0.1/img/"+rset.getString("logo")
                , rset.getFloat("latitude"), rset.getFloat("longitude"), j));
        embeddedWebView.execstring("" +
                        "window.lat = " + rset.getFloat("latitude") + ";" +
                        "window.lon = " + rset.getFloat("longitude") + ";" +
                        "window.num = \"" + j + "\";" +
                        "window.nom =\""+rset.getString("titre")+"\";" +
                          "window.im =\"http://127.0.0.1/img/"+rset.getString("logo")+"\";" +
                        "test(window.lat, window.lon,window.num,window.nom,window.im);"
                    );
        j++;
   
        }
         propList.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<CustomThing>() {

            @Override
            public void changed(ObservableValue<? extends CustomThing> observable, CustomThing oldValue, CustomThing newValue) {
               
               embeddedWebView.execstring("myClick("+(newValue.getNum()-1)+");");
            }
        });
        
    }
    @FXML
    private void promoFilter(ActionEvent event) {
    }

    /**
     * Initializes the controller class.
     */
    
     private static class CustomThing {
         private int idProp;

        public CustomThing(int idProp, String name, Rating str, String url, double lat, double lon, int num) {
            this.idProp = idProp;
            this.name = name;
            this.str = str;
            this.url = url;
            this.lat = lat;
            this.lon = lon;
            this.num = num;
        }

        public int getIdProp() {
            return idProp;
        }

        public void setIdProp(int idProp) {
            this.idProp = idProp;
        }
        private String name;
        private int price;
        private Rating str;
        private String url;
        private double lat;
        private double lon;
        private int num;

        public CustomThing(String name, Rating str, String url, double lat, double lon, int num) {
            this.name = name;
            this.str = str;
            this.url = url;
            this.lat = lat;
            this.lon = lon;
            this.num = num;
        }

        public int getNum() {
            return num;
        }

        public void setNum(int num) {
            this.num = num;
        }

        public CustomThing(String name, Rating str, String url, double lat, double lon) {
            this.name = name;
            this.str = str;
            this.url = url;
            this.lat = lat;
            this.lon = lon;
        }

        public double getLat() {
            return lat;
        }

        public void setLat(double lat) {
            this.lat = lat;
        }

        public double getLon() {
            return lon;
        }

        public void setLon(double lon) {
            this.lon = lon;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }
        public String getName() {
            return name;
        }
        public int getPrice() {
            return price;
        }
        public CustomThing(String name, Rating str,String url) {
            super();
            this.name = name;
            this.str = str;
            this.url = url;
        }

    }
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        i=1;
        UpdateableListViewSkin<CustomThing> skin = new UpdateableListViewSkin<>(this.propList);
        this.propList.setSkin(skin);
        ((UpdateableListViewSkin) propList.getSkin()).refresh();
        // TODO
        ResultSet rs = null;
         ProprieteService ps = new ProprieteService();
        try {
            rs = ps.afficherPropriete();
            
        } catch (SQLException ex) {
            Logger.getLogger(RecherchePropController.class.getName()).log(Level.SEVERE, null, ex);
        }
      
        ObservableList<CustomThing> data = FXCollections.observableArrayList();
        
        Rating r = new Rating();
        r.setRating(3);
        try {
            
            while(rs.next()){
            
            data.addAll(new CustomThing(rs.getInt("id"),i+". "+rs.getString("titre"), r,"http://127.0.0.1/img/"+rs.getString("logo"),rs.getFloat("latitude")
                    ,rs.getFloat("longitude"),i));
             embeddedWebView.exectest("" +
                        "window.lat = " + rs.getFloat("latitude") + ";" +
                        "window.lon = " + rs.getFloat("longitude") + ";" +
                        "window.num = \"" + i + "\";" +
                        "window.nom =\""+rs.getString("titre")+"\";" +
                        "window.im =\""+"http://127.0.0.1/img/"+rs.getString("logo")+"\";" +
                        "test(window.lat, window.lon,window.num,window.nom,window.im);"
                    );
            i++;
            }
        } catch (SQLException ex) {
            Logger.getLogger(RecherchePropController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
            
                //new CustomThing("Horse", 456), new CustomThing("Jam", 789));

        propList.getItems().addAll(data);
        propList.setCellFactory(new Callback<ListView<CustomThing>, ListCell<CustomThing>>() {

            @Override
            public ListCell<CustomThing> call(ListView<CustomThing> arg0) {
                return new ListCell<CustomThing>() {

                    @Override
                    protected void updateItem(CustomThing item, boolean bln) {
                        super.updateItem(item, bln);
                        if (item != null) {
                            Rating rss = new Rating();
                            rss.getStylesheets().add("pi/fxml1.css");
                            Text t =new Text(item.getName());
                            t.setStyle("-fx-font-size: 25 arial;");
                            //t.setFill(Color.web("#ff214f"));
                           
                            Button bt =new Button("save");
                            bt.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                PI.idp=item.getIdProp();
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("affichProp.fxml"));
            Parent root = null;
                try {
                    root = (Parent) fxmlLoader.load();
                } catch (IOException ex) {
                    Logger.getLogger(RecherchePropController.class.getName()).log(Level.SEVERE, null, ex);
                }
            Stage stage = new Stage();
            stage.setScene(new Scene(root));  
            stage.show();
            PI.stg.close();
            PI.stg = stage;
            }
        });
                            
                            VBox vBox = new VBox(t, rss
                                    ,new Text("Categorie"),new Text("Z.I. Chotr"
                                            + "ana II B.P. 160"),bt);
                            vBox.setSpacing(4);
                            Image  image  = new Image(item.getUrl(), true); 
                            ImageView imv =new ImageView(image);
                            imv.setFitHeight(130);
                            imv.setFitWidth(130);
                            
                            HBox hBox = new HBox(imv, vBox);
                            hBox.setSpacing(10);
                            
                            
                            setGraphic(hBox);
                           String st =String.valueOf(item.getNum());
                            
                    /*    embeddedWebView.exectest("" +
                        "window.lat = " + item.getLat() + ";" +
                        "window.lon = " + item.getLon() + ";" +
                        "window.num = \"" + item.getNum() + "\";" +
                        "window.nom =\""+item.getName()+"\";" +
                        "window.im =\""+item.getUrl()+"\";" +
                        "test(window.lat, window.lon,window.num,window.nom,window.im);"
                    );*/
                    
                        }else{
                         
        setText(null);
        setGraphic(null);
  
                        }
                    }

                };
            }

        });
        
               propList.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<CustomThing>() {

       
   

            @Override
            public void changed(ObservableValue<? extends CustomThing> observable, CustomThing oldValue, CustomThing newValue) {
               
               embeddedWebView.execstring("myClick("+newValue.getNum()+");");
                System.out.println(newValue.getName());
            }
        });
               ((UpdateableListViewSkin) propList.getSkin()).refresh();
    }    

    @FXML
    private void AddProp(ActionEvent event) {
    }

    @FXML
    private void Insc(ActionEvent event) {
        embeddedWebView.execstring("myClick(0);");
        System.out.println("testtttt");
    }

    @FXML
    private void SgnUp(ActionEvent event) {
    }

    @FXML
    private void prixFilter(ActionEvent event) {
         Node source = (Node) event.getSource();
    Window theStage = source.getScene().getWindow();

        PopOver popover = new PopOver();
        popover.setPrefSize(800,800);
         Rating rss = new Rating();
        rss.getStylesheets().add("pi/fxml1.css");
        VBox vBox = new VBox(rss,new Text("selectionnez le nombre d'étoiles"));
        vBox.setSpacing(10);
       
        popover.setContentNode( vBox);
       popover.show(prixBTN);
    }

    @FXML
    private void ouvertFilter(ActionEvent event) {
    }

    @FXML
    private void equFilter(ActionEvent event) {
        
                Node source = (Node) event.getSource();
    Window theStage = source.getScene().getWindow();

        PopOver popover = new PopOver();
        popover.setPrefSize(800,800);
         JFXCheckBox rss1 = new JFXCheckBox("selectionnez le nombre d'étoiles");
         JFXCheckBox rss2 = new JFXCheckBox("selectionnez le nombre d'étoiles");
         JFXCheckBox rss3 = new JFXCheckBox("selectionnez le nombre d'étoiles");
         JFXCheckBox rss4 = new JFXCheckBox("selectionnez le nombre d'étoiles");
         JFXCheckBox rss5 = new JFXCheckBox("selectionnez le nombre d'étoiles");
         JFXCheckBox rss6 = new JFXCheckBox("selectionnez le nombre d'étoiles");
         //rss.getStylesheets().add("pi/fxml1.css");
        VBox vBox = new VBox(rss1,rss2,rss3,rss4,rss5,rss6);
        vBox.setSpacing(10);
       
        popover.setContentNode( vBox);
       popover.show(equipementBTN);
    }
    
}
