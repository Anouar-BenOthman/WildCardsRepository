/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author Nidhal
 */
public class Tag {
    private String nom;
    private int id_prop;

    public Tag(String nom, int id_prop) {
        this.nom = nom;
        this.id_prop = id_prop;
    }

    public int getId_prop() {
        return id_prop;
    }

    public void setId_prop(int id_prop) {
        this.id_prop = id_prop;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public Tag(String nom) {
        this.nom = nom;
    }
    
}
